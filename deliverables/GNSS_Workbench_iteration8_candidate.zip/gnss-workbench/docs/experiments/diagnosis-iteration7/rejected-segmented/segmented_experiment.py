"""Development-only segmented parity profiles, never receiver-position constraints."""
from dataclasses import replace
from math import log
import numpy as np
from gnss_workbench.core.diagnosis import AmbiguityResolver
from gnss_workbench.core.solver import PositioningEngine


def segmented_costs(samples, candidates, ratio=20):
    count=len(samples)
    if count<3:return None
    t=np.array([s[0]-samples[-1][0] for s in samples])
    r=np.array([s[1] for s in samples])
    diag=np.maximum(np.array([s[2] for s in samples]),1e-12)
    sigma=samples[-1][3]
    w=np.array([1/max(sigma,s[3])**2 for s in samples])
    dof=candidates-4
    penalty=log(max(2,count*dof))
    split_penalty=2*log(ratio*candidates*max(1,count-1))
    prior=np.zeros(count+1)
    costs=np.zeros(candidates)
    starts=np.zeros(candidates,dtype=int)
    for end in range(1,count+1):
        best=np.full(candidates,np.inf); best_null=np.inf
        for start in range(end):
            sl=slice(start,end);tt=t[sl];ww=w[sl];dd=diag[sl];rr=r[sl]
            null=float(np.sum(ww*np.sum(rr**2,axis=1)))
            a=np.sum(ww[:,None]*dd,axis=0)
            z=np.sum(ww[:,None]*rr,axis=0)
            score=np.maximum(0,null-z*z/a)+penalty
            if end-start>=3:
                b=np.sum((ww*tt)[:,None]*dd,axis=0)
                c=np.sum((ww*tt**2)[:,None]*dd,axis=0)
                v=np.sum((ww*tt)[:,None]*rr,axis=0)
                det=a*c-b*b
                safe=det>1e-12
                imp=np.zeros(candidates)
                imp[safe]=(c[safe]*z[safe]**2-2*b[safe]*z[safe]*v[safe]+a[safe]*v[safe]**2)/det[safe]
                linear=np.where(safe,np.maximum(0,null-imp)+2*penalty,np.inf)
                score=np.minimum(score,linear)
            prefix=prior[start]+(split_penalty if start else 0)
            score+=prefix
            if end==count:starts[score<best]=start
            best=np.minimum(best,score)
            best_null=min(best_null,prefix+null)
        prior[end]=min(float(np.min(best)),best_null)
        if end==count:costs=best
    return costs,starts


class SegmentedEngine(PositioningEngine):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        old_observe=self._ambiguity.observe
        def observe(*a,**kw):
            original=old_observe(*a,**kw)
            if original.method=='current_likelihood':return original
            keys=tuple(sorted(a[2]));samples=list(self._temporal.samples)
            if keys!=self._temporal.keys:return original
            evidence=segmented_costs(samples,len(keys),self.config.fde_likelihood_ratio)
            if evidence is None:return original
            costs,starts=evidence
            winner,shares,log_ratio=AmbiguityResolver._compare(costs)
            key=keys[winner];current=min(a[2],key=a[2].get)
            if key not in a[3] or .5*(a[2][key]-a[2][current])>=log(self.config.fde_likelihood_ratio):return original
            count=len(samples)-int(starts[winner])
            confirmed=log_ratio>=log(self.config.fde_likelihood_ratio) and current==key and count>=3
            return replace(original,selected=key if confirmed else None,method='segmented_profile' if confirmed else 'unresolved',tentative=key,tentative_source='segmented_profile',epochs=count,start_time=samples[int(starts[winner])][0],log_ratio=log_ratio,window_shares=dict(zip(keys,map(float,shares),strict=True)))
        self._ambiguity.observe=observe
